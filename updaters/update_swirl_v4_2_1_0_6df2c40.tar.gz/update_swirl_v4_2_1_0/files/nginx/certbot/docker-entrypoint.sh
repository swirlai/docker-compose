#!/bin/sh

trap "exit" TERM

if [ "$USE_CERT" = "true" ]; then
  echo "Using owned certificate. Not starting Certbot service."
else
  echo "Certbot is enabled. Starting the service..."

  while true; do
    certbot renew --no-random-sleep-on-renew --config-dir /app/nginx/certbot/conf
    sleep 12h
  done
fi
