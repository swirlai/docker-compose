#!/usr/bin/env bash

set -e

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
TOOLS_DIR=$SCRIPT_DIR/tools
REPLACEMENT_FILES_DIR=$SCRIPT_DIR/files
TARGET_BASE_DIR=/app
DATESTAMP=$(date +%Y-%b-%d-%H%M)
export DATESTAMP
export ENV_FILE="/app/.env"
export TARGET_VERSION="v4_2_1_0"
export UPDATE_LOG="$TARGET_BASE_DIR/update_${DATESTAMP}.log"
# ----------------------
# Functions
# ----------------------

function info() {
    echo "[$(date +%Y-%m-%dT%H:%M:%S) INFO] $1" | tee -a $UPDATE_LOG
}

function error() {
    echo "[$(date +%Y-%m-%dT%H:%M:%S) ERROR] $1" | tee -a $UPDATE_LOG
    exit 1
}

function update_env_key_value() {
  key=$1
  value=$2
  change_existing_value=${3:-true} # Default to true if not provided

  # if key does not exist, add it
  if ! grep -q "^${key}=" $ENV_FILE; then
    echo "${key}=${value}" >> $ENV_FILE
  elif [ "$change_existing_value" = true ]; then
    # if key exists and change_existing_value is true, update it
    sed -i "s/^${key}=.*/${key}=${value}/" $ENV_FILE
  fi
}

function update_versions() {
  for key in SWIRL TIKA TTM
  do
    KEY_TEXT="${key}_VERSION"
    update_env_key_value $KEY_TEXT $TARGET_VERSION
  done
}
function update_fqdn() {
  source $ENV_FILE
  if [ -n "$FQDN" ]; then
    if [ -z "$SWIRL_FQDN" ]; then
      info "update_fqdn - SWIRL_FQDN is not set. Setting it to FQDN value."
      update_env_key_value "SWIRL_FQDN" "$FQDN"
    fi
  elif [-z "$SWIRL_FQDN" ]; then
    info "update_fqdn - SWIRL_FQDN already set"
  else
    error "Neither FQDN nor SWIRL_FQDN is set in $ENV_FILE. 3.9-4.1 use FQDN, 4.2+ use SWIRL_FQDN. Please set one of them."
  fi
}
# ----------------------
# Main Script
# ----------------------
cd $TARGET_BASE_DIR

info "Updater Environment"
info " SCRIPT_DIR: $SCRIPT_DIR"
info " TOOLS_DIR: $TOOLS_DIR"
info " REPLACEMENT_FILES_DIR: $REPLACEMENT_FILES_DIR"
info " TARGET_BASE_DIR: $TARGET_BASE_DIR"
info " DATESTAMP: $DATESTAMP"
info " TARGET_VERSION: $TARGET_VERSION"

info "Installing Tools Scripts"
rsync -rvlHtogpc $TOOLS_DIR/ $TARGET_BASE_DIR
chmod +x $TARGET_BASE_DIR/*.sh

info "Backing up environment"
$TOOLS_DIR/backup.sh | tee -a $UPDATE_LOG

info 'Stopping swirl service'
systemctl stop swirl  | tee -a $UPDATE_LOG

info "Starting Docker Authentication for swirlai image pulls"
$TOOLS_DIR/docker_login.sh
info "Docker Authentication completed"

info "Updating .env"
cp $ENV_FILE /app/env.${DATESTAMP}.bak
update_versions
update_fqdn

# only update USE_CERT when it does not exist
update_env_key_value USE_CERT false false

source  $ENV_FILE
if [ "$SWIRL_VERSION" !=  "$TARGET_VERSION" ] || [ "$TIKA_VERSION" != "$TARGET_VERSION" ] || [ "$TTM_VERSION" != "$TARGET_VERSION" ]; then
    error "SWIRL_VERSION (${SWIRL_VERSION}), TIKA_VERSION (${TIKA_VERSION}), and TTM_VERSION (${TTM_VERSION}) in $ENV_FILE must match $TARGET_VERSION. Please update your $ENV_FILE."
fi

info "Installing update files"
pushd $REPLACEMENT_FILES_DIR
rsync -rvlHogpc . --backup --suffix=_backup $TARGET_BASE_DIR  | tee -a $UPDATE_LOG
popd

info "Pulling Images"
docker compose --profile all pull | tee -a $UPDATE_LOG

info "Update complete."
info "Please restart swirl to apply changes. systemctl restart swirl"
info " You can monitor the logs with journalctl -u swirl -f"

