#!/bin/bash

# Disable X11 for gui applications
export DBUS_SESSION_BUS_ADDRESS=/dev/null

function log() {
    echo "[$(date +%Y-%m-%dT%H:%M:%S) ${STAGE}] $1"
}

function error() {
    echo "[$(date +%Y-%m-%dT%H:%M:%S) ${STAGE} ERROR] $1"
}

mkdir -p /var/log/swirl
exec > >(tee -a /var/log/swirl/swirl.log) 2>&1

FLAG_FILE="./swirl_job.flag"
ENV_FILE="./.env"
EXAMPLE_ENV_FILE="/app/.env.example"

if [ ! -f "$ENV_FILE" ]; then
    log ".env file does not exist. Copying $EXAMPLE_ENV_FILE to $ENV_FILE..."

    if [ -f "$EXAMPLE_ENV_FILE" ]; then
        cp "$EXAMPLE_ENV_FILE" "$ENV_FILE"
        log ".env file created successfully."
    else
        error ".env.example file not found. Cannot create .env file."
        exit 1
    fi
else
    log ".env file already exists."
fi

source "$ENV_FILE"

log "Stopping any swirl containers from previous run"
docker compose --profile all stop

if [ "$USE_LOCAL_POSTGRES" == "true" ]; then
    log "Starting local Postgres."
    COMPOSE_PROFILES=db docker compose up --pull never -d
    log "Started local Postgres."
    sleep 15
fi

COMPOSE_PROFILES=svc

if [ "$USE_NGINX" == "true" ]; then
    COMPOSE_PROFILES="$COMPOSE_PROFILES,nginx"

    if [ "$USE_TLS" == "true" ]; then
        if [ "$USE_CERT" == "false" ]; then
            log "TLS enabled with Certbot. Starting Nginx and Certbot."
            log "Issuing certificate using Certbot."

              info "Waiting DNS propagation before Certbot request..."
              MAX_WAIT=300
              WAITED=0
              while ! getent hosts "$SWIRL_FQDN" >/dev/null; do
                  if [ "$WAITED" -ge "$MAX_WAIT" ]; then
                      error "DNS name $SWIRL_FQDN did not resolve after $MAX_WAIT seconds."
                      exit 1
                  fi
                  sleep 1
                  WAITED=$((WAITED + 1))
              done
              info "DNS name $SWIRL_FQDN resolved after $WAITED seconds."


            TEMPLATE_FILE="nginx/nginx.template.tls"
            SNIPPET="ssl_certificate /etc/letsencrypt/live/\${SWIRL_FQDN}/fullchain.pem;"

            if ! grep -Fq "$SNIPPET" "$TEMPLATE_FILE"; then
                awk '
                {
                    if (prev ~ /listen 443 ssl;/ && $0 ~ /server_name .*;/) {
                        print
                        print ""
                        print "    ssl_certificate /etc/letsencrypt/live/${SWIRL_FQDN}/fullchain.pem;"
                        print "    ssl_certificate_key /etc/letsencrypt/live/${SWIRL_FQDN}/privkey.pem;"
                        print "    include /etc/letsencrypt/options-ssl-nginx.conf;"
                        print "    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;"
                    } else {
                        print
                    }
                    prev = $0
                }
                ' "$TEMPLATE_FILE" > tmp && mv tmp "$TEMPLATE_FILE"
            fi
            
            CERTBOT_SOURCE_DIR="/app/nginx/certbot/conf"
            OPTIONS_FILE="$CERTBOT_SOURCE_DIR/options-ssl-nginx.conf"
            DHPARAMS_FILE="$CERTBOT_SOURCE_DIR/ssl-dhparams.pem"
            
            TARGET_LOCATIONS="/etc/letsencrypt /etc/nginx/ssl"

            for DIR in $TARGET_LOCATIONS; do
                mkdir -p "$DIR"
                cp "$OPTIONS_FILE" "$DIR/"
                cp "$DHPARAMS_FILE" "$DIR/"
                echo "Copied TLS configs to $DIR"
            done

            certbot certonly --standalone --email $CERTBOT_EMAIL --agree-tos --no-eff-email -d "${SWIRL_FQDN}" --config-dir /app/nginx/certbot/conf

            cp nginx/nginx.template.tls nginx/nginx.template
            COMPOSE_PROFILES="$COMPOSE_PROFILES,certbot"

        elif [ "$USE_CERT" == "true" ]; then
            log "TLS enabled with owned certificate. Starting Nginx without Certbot."

            CERT_PATH="/app/nginx/certificates/ssl/${SWIRL_FQDN}"
            if [ -f "$CERT_PATH/ssl_certificate.crt" ] && [ -f "$CERT_PATH/ssl_certificate_key.key" ]; then
              log "Found owned certificate and key in '${CERT_PATH}'"
                TEMPLATE_FILE="nginx/nginx.template.tls"
                SNIPPET="ssl_certificate /etc/nginx/ssl/\${SWIRL_FQDN}/ssl_certificate.crt;"

                if ! grep -Fq "$SNIPPET" "$TEMPLATE_FILE"; then
                    log "Updating Nginx template with owned certificate paths."
                    awk '
                    {
                        if (prev ~ /listen 443 ssl;/ && $0 ~ /server_name .*;/) {
                            print
                            print ""
                            print "    ssl_certificate /etc/nginx/ssl/${SWIRL_FQDN}/ssl_certificate.crt;"
                            print "    ssl_certificate_key /etc/nginx/ssl/${SWIRL_FQDN}/ssl_certificate_key.key;"
                        } else {
                            print
                        }
                        prev = $0
                    }
                    ' "$TEMPLATE_FILE" > tmp && mv tmp "$TEMPLATE_FILE"
                else
                    log "Nginx template already contains the owned certificate paths."
                fi
            else
                error "Certificate or key not found in '${CERT_PATH}'."
            fi

            cp nginx/nginx.template.tls nginx/nginx.template
        fi
    else
        log "TLS is disabled. Starting Nginx without TLS."
        cp nginx/nginx.template.notls nginx/nginx.template
    fi
else
    log "USE_NGINX is false. Nginx will not be started."
    cp nginx/nginx.template.notls nginx/nginx.template
fi

if [ -f "$FLAG_FILE" ]; then
    log "Not first time execution."
else
    log "First time execution."
    log "Enabling Swirl service to start on boot..."
    systemctl enable swirl
    COMPOSE_PROFILES="$COMPOSE_PROFILES,setup"
    touch "$FLAG_FILE"
fi

log "Docker Compose Up with profiles: $COMPOSE_PROFILES"
COMPOSE_PROFILES=$COMPOSE_PROFILES docker compose up --pull never