#!/bin/bash
DJANGO_SUPERUSER_PASSWORD=$ADMIN_PASSWORD python manage.py createsuperuser --email $ADMIN_USER_EMAIL --username admin --noinput;
if [ -n "$MSAL_AUTH_REDIRECT_URI" ]; then
echo "MSAL configuration detected, M365 Search Providers will be enabled";
jq 'map(if .name == "Outlook Messages - Microsoft 365" then .active = true else . end)' /app/SearchProviders/preloaded.json > /app/temp && mv /app/temp /app/SearchProviders/preloaded.json;
jq 'map(if .name == "Calendar Events - Microsoft 365" then .active = true else . end)' /app/SearchProviders/preloaded.json > /app/temp && mv /app/temp /app/SearchProviders/preloaded.json;
jq 'map(if .name == "OneDrive Files - Microsoft 365" then .active = true else . end)' /app/SearchProviders/preloaded.json > /app/temp && mv /app/temp /app/SearchProviders/preloaded.json;
jq 'map(if .name == "SharePoint Sites - Microsoft 365" then .active = true else . end)' /app/SearchProviders/preloaded.json > /app/temp && mv /app/temp /app/SearchProviders/preloaded.json;
jq 'map(if .name == "Teams Chat - Microsoft 365" then .active = true else . end)' /app/SearchProviders/preloaded.json > /app/temp && mv /app/temp /app/SearchProviders/preloaded.json;

if [ -n "$MICROSOFT_CLIENT_SECRET" ]; then
  echo "MSAL configuration detected, Microsoft authentication for search providers will be enabled"
  AUTH_TARGET='/app/swirl/fixtures/DefaultAuthenticators.json'

  # use env to update default authenticator for microsoft
  jq '.[0].fields.active = true' $AUTH_TARGET > /app/temp && mv /app/temp $AUTH_TARGET
  jq '.[0].fields.client_id = "'"$MICROSOFT_CLIENT_ID"'"' $AUTH_TARGET > /app/temp && mv /app/temp $AUTH_TARGET
  jq '.[0].fields.client_secret = "'"$MICROSOFT_CLIENT_SECRET"'"' $AUTH_TARGET > /app/temp && mv /app/temp $AUTH_TARGET;
  jq '.[0].fields.app_uri = "'"https://$SWIRL_FQDN"'"' $AUTH_TARGET > /app/temp && mv /app/temp $AUTH_TARGET;
  jq '.[0].fields.auth_uri = "'"$MSAL_AUTH_AUTHORITY"'"' $AUTH_TARGET > /app/temp && mv /app/temp $AUTH_TARGET;
  jq '.[0].fields.token_uri = "'"$OAUTH_CONFIG_TOKEN_ENDPOINT"'"' $AUTH_TARGET > /app/temp && mv /app/temp $AUTH_TARGET;
else
  echo "No MICROSOFT_CLIENT_SECRET configuration detected, Microsoft authentication for search providers will not be enabled";
fi


else
echo "No MSAL configuration detected, M365 Search Providers will not be enabled";
fi
if [ "$AZ_GOV_COMPATIBLE" == "true" ]; then
echo "Processing Search Providers for Azure Government";
sed 's/microsoft.com/microsoft.us/g' /app/SearchProviders/preloaded.json > /app/temp && mv /app/temp /app/SearchProviders/preloaded.json
else
echo "No MSAL configuration detected, M365 Search Providers will not be enabled";
fi
python swirl.py load_data;